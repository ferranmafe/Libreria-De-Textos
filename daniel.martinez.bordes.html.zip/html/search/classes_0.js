var searchData=
[
  ['autor',['Autor',['../struct_cjt___textos_1_1_autor.html',1,'Cjt_Textos']]]
];
