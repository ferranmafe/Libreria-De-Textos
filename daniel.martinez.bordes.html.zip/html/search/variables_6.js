var searchData=
[
  ['text',['text',['../class_text.html#a15cbdc45b63c0314e8fbd1f39ac2c4c1',1,'Text']]],
  ['text_5fseleccionat',['text_seleccionat',['../class_cjt___textos.html#a55c3d2780427a8c676129318b45518d9',1,'Cjt_Textos']]],
  ['textos',['textos',['../class_cjt___textos.html#a28718e2d0fa9d942eb035666ab447540',1,'Cjt_Textos']]],
  ['tipus_5fparaules',['tipus_paraules',['../class_text.html#a44cb4f8324103cef72686be4389611a3',1,'Text']]],
  ['titol',['titol',['../class_text.html#afb1a3dffe94a4342ea0337f1a40eb5f6',1,'Text']]],
  ['títol',['títol',['../class_cita.html#a5e82bd1bbba756fea5153687293f8dbb',1,'Cita']]]
];
