var searchData=
[
  ['llegir_5fllista_5fstring',['llegir_llista_string',['../main_8cc.html#a97af8421c5a6d0ec739bb581597bfc00',1,'main.cc']]]
];
