var searchData=
[
  ['afegir_5fcita',['afegir_cita',['../class_cjt__cites.html#a64bfbbf1f4b8cbaa9925062239ecc6fe',1,'Cjt_cites']]],
  ['afegir_5ftext',['afegir_text',['../class_cjt___textos.html#ab8d0c56ec711b233319f17c989d1ebbd',1,'Cjt_Textos']]]
];
