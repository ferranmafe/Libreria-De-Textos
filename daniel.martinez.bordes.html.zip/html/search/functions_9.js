var searchData=
[
  ['referencia_5fvalida',['referencia_valida',['../class_cjt__cites.html#ab55211b6ae24fa8431180d4ef2dc3f9e',1,'Cjt_cites']]]
];
