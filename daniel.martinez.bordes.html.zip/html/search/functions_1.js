var searchData=
[
  ['calcul_5ffreqüencies',['calcul_freqüencies',['../class_text.html#a54ec06b6ee7b13c9d362c117f40239da',1,'Text']]],
  ['cerca_5fstring',['cerca_string',['../class_frase.html#a3fdcd642fddec85944455f9d273e576a',1,'Frase']]],
  ['cita',['Cita',['../class_cita.html#a40ebe4fd414fa884f1aca3b78e77a38c',1,'Cita']]],
  ['cites',['cites',['../class_cjt__cites.html#a537d95cc929397d0483d8049dd2d19e7',1,'Cjt_cites']]],
  ['cites_5fautor',['cites_autor',['../class_cjt__cites.html#a7924572809f07bae67a3228267269512',1,'Cjt_cites']]],
  ['cjt_5fcites',['Cjt_cites',['../class_cjt__cites.html#a7d7168fec29d5ee09ed67c6a0d837b53',1,'Cjt_cites']]],
  ['cjt_5ftextos',['Cjt_Textos',['../class_cjt___textos.html#a294e9acbffc974a871f9417579390ad4',1,'Cjt_Textos']]],
  ['consultar_5fautor',['consultar_autor',['../class_cita.html#a182db13f894354082ce61b4240610c1b',1,'Cita']]],
  ['consultar_5fcita',['consultar_cita',['../class_cita.html#a2dcd2a80cf4b7d1f95740c885bba10b1',1,'Cita::consultar_cita()'],['../class_cjt__cites.html#a27fef329a813a83b977c6dd16e70090d',1,'Cjt_cites::consultar_cita()']]],
  ['consultar_5ffrase',['consultar_frase',['../class_frase.html#ae3b0cbb6e62033f51e248adbe540e52c',1,'Frase']]],
  ['consultar_5fnparaules',['consultar_nparaules',['../class_frase.html#a91e5ab86e32ba7f11474ba270cd7026e',1,'Frase']]],
  ['consultar_5freferencia',['consultar_referencia',['../class_cita.html#ab8340c7e64d59ac93b7bf7ebdd3904b6',1,'Cita']]],
  ['consultar_5ftitol',['consultar_titol',['../class_cita.html#a8dee3e5f4acb524663abc16d95bf7f9f',1,'Cita']]]
];
