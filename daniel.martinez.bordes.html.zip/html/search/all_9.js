var searchData=
[
  ['n_5fparaules',['n_paraules',['../class_frase.html#adc9c5450047224df1f95d1a71ec7fee6',1,'Frase']]],
  ['nfrases',['nfrases',['../struct_cjt___textos_1_1_autor.html#a849846d3c6ff70df4b46f648fea7831b',1,'Cjt_Textos::Autor']]],
  ['nombre_5ffrases',['nombre_frases',['../class_text.html#ad096d9bcf4850acb38f77316f5b2cacd',1,'Text']]],
  ['nparaules',['nparaules',['../struct_cjt___textos_1_1_autor.html#a0480d67626f691bc95522066c8196220',1,'Cjt_Textos::Autor']]],
  ['ntextos',['ntextos',['../struct_cjt___textos_1_1_autor.html#aec8671be8f5e2928dff24d9520f99fb5',1,'Cjt_Textos::Autor']]]
];
