var searchData=
[
  ['substitueix_5fparaules',['substitueix_paraules',['../class_text.html#ae4c72338544f708e1b8c2f26b6cb9616',1,'Text']]]
];
