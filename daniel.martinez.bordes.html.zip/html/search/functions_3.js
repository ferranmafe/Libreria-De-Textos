var searchData=
[
  ['frase',['Frase',['../class_frase.html#a6af6ccf07cac65950917bc81f5e03c95',1,'Frase']]],
  ['frases',['frases',['../class_text.html#af2df0febe58d16947cba7925fc60f1b1',1,'Text']]],
  ['frases_5fexpressio',['frases_expressio',['../class_text.html#a9c0ef460dc9b6ce232162a8b5aeaa4e6',1,'Text']]],
  ['frases_5fsequencia',['frases_sequencia',['../class_text.html#af512750511886ba5b4a1df4d55498a32',1,'Text']]]
];
