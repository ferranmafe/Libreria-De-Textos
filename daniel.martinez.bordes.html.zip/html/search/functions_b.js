var searchData=
[
  ['taula_5ffrequencies',['taula_frequencies',['../class_text.html#a1b074c592cef2ed66b09972dad6d0d4e',1,'Text']]],
  ['text',['Text',['../class_text.html#ab3e26143fccc52699bcc5149cae852bc',1,'Text']]],
  ['text_5ftriat',['text_triat',['../class_cjt___textos.html#a2889075ae004888ba03b7eff2d18b029',1,'Cjt_Textos']]],
  ['textos_5fautor',['textos_autor',['../class_cjt___textos.html#aeb3e88e296d3be6ad582d3ecb2913b18',1,'Cjt_Textos']]],
  ['totes_5fcites',['totes_cites',['../class_cjt__cites.html#ab3cf10c876f23dddd104b5a076be6f69',1,'Cjt_cites']]],
  ['tots_5fautors',['tots_autors',['../class_cjt___textos.html#ae6c5751ee3e8c46747fd996ea04a2e03',1,'Cjt_Textos']]],
  ['tots_5ftextos',['tots_textos',['../class_cjt___textos.html#a6af24c74bc787f98e27989ccbf7b791d',1,'Cjt_Textos']]],
  ['triar_5ftext',['triar_text',['../class_cjt___textos.html#a448e0759a6695bcec2dc22d9120ae05a',1,'Cjt_Textos']]]
];
