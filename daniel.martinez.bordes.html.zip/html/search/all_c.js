var searchData=
[
  ['taula_5ffrequencies',['taula_frequencies',['../class_text.html#a1b074c592cef2ed66b09972dad6d0d4e',1,'Text']]],
  ['text',['Text',['../class_text.html',1,'Text'],['../class_text.html#ab3e26143fccc52699bcc5149cae852bc',1,'Text::Text()'],['../class_text.html#a15cbdc45b63c0314e8fbd1f39ac2c4c1',1,'Text::text()']]],
  ['text_2ehh',['Text.hh',['../_text_8hh.html',1,'']]],
  ['text_5fseleccionat',['text_seleccionat',['../class_cjt___textos.html#a55c3d2780427a8c676129318b45518d9',1,'Cjt_Textos']]],
  ['text_5ftriat',['text_triat',['../class_cjt___textos.html#a2889075ae004888ba03b7eff2d18b029',1,'Cjt_Textos']]],
  ['textos',['textos',['../class_cjt___textos.html#a28718e2d0fa9d942eb035666ab447540',1,'Cjt_Textos']]],
  ['textos_5fautor',['textos_autor',['../class_cjt___textos.html#aeb3e88e296d3be6ad582d3ecb2913b18',1,'Cjt_Textos']]],
  ['tipus_5fparaules',['tipus_paraules',['../class_text.html#a44cb4f8324103cef72686be4389611a3',1,'Text']]],
  ['titol',['titol',['../class_text.html#afb1a3dffe94a4342ea0337f1a40eb5f6',1,'Text']]],
  ['totes_5fcites',['totes_cites',['../class_cjt__cites.html#ab3cf10c876f23dddd104b5a076be6f69',1,'Cjt_cites']]],
  ['tots_5fautors',['tots_autors',['../class_cjt___textos.html#ae6c5751ee3e8c46747fd996ea04a2e03',1,'Cjt_Textos']]],
  ['tots_5ftextos',['tots_textos',['../class_cjt___textos.html#a6af24c74bc787f98e27989ccbf7b791d',1,'Cjt_Textos']]],
  ['triar_5ftext',['triar_text',['../class_cjt___textos.html#a448e0759a6695bcec2dc22d9120ae05a',1,'Cjt_Textos']]],
  ['títol',['títol',['../class_cita.html#a5e82bd1bbba756fea5153687293f8dbb',1,'Cita']]]
];
