var searchData=
[
  ['map_3c_20string_2c_20autor_20_3e',['map&lt; string, Autor &gt;',['../class_cjt___textos.html#ac72ee22f626ff7b686b6d413d1bcf42e',1,'Cjt_Textos']]]
];
