var searchData=
[
  ['eliminar_5fcita',['eliminar_cita',['../class_cjt__cites.html#a6d312b154a06384310a7f2b9f630fd7d',1,'Cjt_cites']]],
  ['eliminar_5ftext',['eliminar_text',['../class_cjt___textos.html#a69c7fdefd849715024904dda5fa32118',1,'Cjt_Textos']]]
];
