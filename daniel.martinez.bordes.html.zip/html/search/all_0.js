var searchData=
[
  ['afegir_5fcita',['afegir_cita',['../class_cjt__cites.html#a64bfbbf1f4b8cbaa9925062239ecc6fe',1,'Cjt_cites']]],
  ['afegir_5ftext',['afegir_text',['../class_cjt___textos.html#ab8d0c56ec711b233319f17c989d1ebbd',1,'Cjt_Textos']]],
  ['autor',['autor',['../class_cita.html#aad675e04320a9a25801392459a5860b4',1,'Cita::autor()'],['../class_text.html#a9c92496907a84813295eff4969492b24',1,'Text::autor()']]],
  ['autor',['Autor',['../struct_cjt___textos_1_1_autor.html',1,'Cjt_Textos']]]
];
