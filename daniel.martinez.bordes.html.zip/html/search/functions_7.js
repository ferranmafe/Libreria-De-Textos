var searchData=
[
  ['main',['main',['../main_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.cc']]],
  ['modificar_5fautor',['modificar_autor',['../class_cita.html#a8b057d0c8b6825aabfb5baf22bcff0ea',1,'Cita::modificar_autor()'],['../class_text.html#a076b142019176524dd24cab1e4704913',1,'Text::modificar_autor()']]],
  ['modificar_5fcita',['modificar_cita',['../class_cita.html#a0810a572bc49939318e29a840fb73a41',1,'Cita::modificar_cita()'],['../class_cjt__cites.html#a27afc9206ff9a545ac70791642a5eccb',1,'Cjt_cites::modificar_cita()']]],
  ['modificar_5ffrase',['modificar_frase',['../class_frase.html#a7ad0a5a794150dc08436deca85440fa6',1,'Frase::modificar_frase()'],['../class_text.html#afec41b50a7b282a8922bcd4a5b8b6d12',1,'Text::modificar_frase()']]],
  ['modificar_5freferencia',['modificar_referencia',['../class_cita.html#a7caee456196298b7e3e77da860f83d5c',1,'Cita']]],
  ['modificar_5ftext',['modificar_text',['../class_cjt___textos.html#ae48cadc0a9cee5c1918e25d313f62de0',1,'Cjt_Textos']]],
  ['modificar_5ftitol',['modificar_titol',['../class_cita.html#a44c924628e7e6c67d43663fc2ddb115f',1,'Cita::modificar_titol()'],['../class_text.html#a3ef81cb3e5c63cccc13eb91fc16c9c0f',1,'Text::modificar_titol(list&lt; string &gt; titol)'],['../class_text.html#a3ef81cb3e5c63cccc13eb91fc16c9c0f',1,'Text::modificar_titol(list&lt; string &gt; titol)']]],
  ['mostrar_5fautor',['mostrar_autor',['../class_text.html#a752879439899d7b0122a6f1a14a26255',1,'Text']]],
  ['mostrar_5fcontingut',['mostrar_contingut',['../class_text.html#a70aebbbeea807f3c5c17b251a51e471c',1,'Text']]],
  ['mostrar_5ftitol',['mostrar_titol',['../class_text.html#ae22b298eaf2660febc0142b4957eddc0',1,'Text']]]
];
