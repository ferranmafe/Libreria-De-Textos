var searchData=
[
  ['nombre_5ffrases',['nombre_frases',['../class_text.html#ad096d9bcf4850acb38f77316f5b2cacd',1,'Text']]]
];
