var searchData=
[
  ['info',['info',['../class_cjt___textos.html#a5c1b1371447a0c0928401b4d99684be3',1,'Cjt_Textos']]],
  ['informacio_5fcita',['informacio_cita',['../class_cjt__cites.html#a45039d85f0f1a35c2f6268bd4bf3744a',1,'Cjt_cites']]]
];
