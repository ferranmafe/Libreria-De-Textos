var searchData=
[
  ['frase',['frase',['../class_frase.html#ae5ba82c3c84c57b225e955d571d69c5d',1,'Frase']]]
];
