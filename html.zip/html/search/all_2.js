var searchData=
[
  ['dades_5fautors',['dades_autors',['../class_cjt___textos.html#a156f4e372acab921fc51b68a1aa33e0f',1,'Cjt_Textos']]]
];
