var searchData=
[
  ['referencia',['referencia',['../class_cita.html#a8e095562c9abad326bcc1e7e86f87b4e',1,'Cita']]],
  ['referencies',['referencies',['../class_cjt__cites.html#a0d968e0d51dfcde4babe1e96617e8d39',1,'Cjt_cites']]]
];
