var searchData=
[
  ['a_5fbuit',['a_buit',['../class_arbre.html#aa74ec0d2b601487b822eb70100330582',1,'Arbre']]],
  ['afegir_5fcita',['afegir_cita',['../class_cjt__cites.html#a49f4daddc0ca649f77653dd842aebe8f',1,'Cjt_cites']]],
  ['afegir_5ftext',['afegir_text',['../class_cjt___textos.html#ab8d0c56ec711b233319f17c989d1ebbd',1,'Cjt_Textos']]],
  ['arbre',['Arbre',['../class_arbre.html#a3f613426983169266297eb841996845e',1,'Arbre::Arbre()'],['../class_arbre.html#a8f8615c19988334f9b77dc51f44acc6d',1,'Arbre::Arbre(const Arbre &amp;original)']]],
  ['arrel',['arrel',['../class_arbre.html#aa6e2559ead7dfceda962cff11fb1a15c',1,'Arbre']]]
];
