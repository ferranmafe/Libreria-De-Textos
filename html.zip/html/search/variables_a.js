var searchData=
[
  ['text',['text',['../class_text.html#a15cbdc45b63c0314e8fbd1f39ac2c4c1',1,'Text']]],
  ['text_5fmodificat',['text_modificat',['../class_text.html#a2dffce8a1b861805e37492a717a4dc3b',1,'Text']]],
  ['text_5fseleccionat',['text_seleccionat',['../class_cjt___textos.html#ad26e8b990001dc47f643761cd1f78441',1,'Cjt_Textos']]],
  ['textos',['textos',['../class_cjt___textos.html#a388444ce5ae47d22520b07dabdfedb56',1,'Cjt_Textos']]],
  ['tipus_5fparaules',['tipus_paraules',['../class_text.html#abfbd2a1eb60b44d60d16848fe84d467f',1,'Text']]],
  ['titol',['titol',['../class_cita.html#af68060127129ab645e0134e4ee1e5fbe',1,'Cita::titol()'],['../class_text.html#afb1a3dffe94a4342ea0337f1a40eb5f6',1,'Text::titol()']]]
];
