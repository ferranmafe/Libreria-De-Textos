var searchData=
[
  ['llegir_5farbre',['llegir_arbre',['../_o_p__aux_8cc.html#a476415b92124f1a78a93c2cd4f6fce5f',1,'llegir_arbre(Arbre&lt; list&lt; string &gt; &gt; &amp;a, list&lt; string &gt; &amp;expressio):&#160;OP_aux.cc'],['../_o_p__aux_8hh.html#a476415b92124f1a78a93c2cd4f6fce5f',1,'llegir_arbre(Arbre&lt; list&lt; string &gt; &gt; &amp;a, list&lt; string &gt; &amp;expressio):&#160;OP_aux.cc']]],
  ['llegir_5fautor',['llegir_autor',['../_o_p__aux_8cc.html#afea1e98dcda4c1d72585105822afa258',1,'llegir_autor():&#160;OP_aux.cc'],['../_o_p__aux_8hh.html#afea1e98dcda4c1d72585105822afa258',1,'llegir_autor():&#160;OP_aux.cc']]],
  ['llegir_5fexpressio_5ffrases',['llegir_expressio_frases',['../program_8cc.html#ab7ed1b0fbc4754537db1e181d7e1d7a0',1,'program.cc']]],
  ['llegir_5ffrase',['llegir_frase',['../_o_p__aux_8cc.html#a018d58c651520deeb02319776e6988f0',1,'llegir_frase(string &amp;paraula):&#160;OP_aux.cc'],['../_o_p__aux_8hh.html#a018d58c651520deeb02319776e6988f0',1,'llegir_frase(string &amp;paraula):&#160;OP_aux.cc']]],
  ['llegir_5fsequencia',['llegir_sequencia',['../program_8cc.html#a661e24ef6906f2460c0996ef826560cf',1,'program.cc']]],
  ['llegir_5ftext',['llegir_text',['../_o_p__aux_8cc.html#ac682c440082e0563141246c74ee4735b',1,'llegir_text():&#160;OP_aux.cc'],['../_o_p__aux_8hh.html#ac682c440082e0563141246c74ee4735b',1,'llegir_text():&#160;OP_aux.cc']]],
  ['llegir_5ftitol',['llegir_titol',['../_o_p__aux_8cc.html#a2953b2afea34d6b88afaf8f4aefc128d',1,'llegir_titol():&#160;OP_aux.cc'],['../_o_p__aux_8hh.html#a2953b2afea34d6b88afaf8f4aefc128d',1,'llegir_titol():&#160;OP_aux.cc']]]
];
