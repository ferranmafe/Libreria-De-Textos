var searchData=
[
  ['autor',['autor',['../class_cita.html#aad675e04320a9a25801392459a5860b4',1,'Cita::autor()'],['../class_text.html#a9c92496907a84813295eff4969492b24',1,'Text::autor()']]]
];
