var searchData=
[
  ['eliminar_5fcita',['eliminar_cita',['../class_cjt__cites.html#aa9fe395ebee9ffd6c4de83d199481af4',1,'Cjt_cites']]],
  ['eliminar_5ftext',['eliminar_text',['../class_cjt___textos.html#a69c7fdefd849715024904dda5fa32118',1,'Cjt_Textos']]],
  ['es_5fbuit',['es_buit',['../class_arbre.html#a68a51f6689f0b2889e8e1d56266fd620',1,'Arbre']]],
  ['esborra_5fnode_5farbre',['esborra_node_arbre',['../class_arbre.html#ab97c98d266a5b8973fe2519c14cf362a',1,'Arbre']]],
  ['escriure_5fautor',['escriure_autor',['../_o_p__aux_8cc.html#a8831f44a33ff2da2134593d5a136a8c4',1,'escriure_autor(const list&lt; string &gt; &amp;autor):&#160;OP_aux.cc'],['../_o_p__aux_8hh.html#a8831f44a33ff2da2134593d5a136a8c4',1,'escriure_autor(const list&lt; string &gt; &amp;autor):&#160;OP_aux.cc']]],
  ['escriure_5fexpressio',['escriure_expressio',['../_o_p__aux_8cc.html#a32d9ab082986e5e82f9b41e6772a0a38',1,'escriure_expressio(const list&lt; string &gt; &amp;expressio):&#160;OP_aux.cc'],['../_o_p__aux_8hh.html#a32d9ab082986e5e82f9b41e6772a0a38',1,'escriure_expressio(const list&lt; string &gt; &amp;expressio):&#160;OP_aux.cc']]],
  ['escriure_5ffrase',['escriure_frase',['../_o_p__aux_8cc.html#ac9111d87787b58aa6daee2cffb0d03f2',1,'escriure_frase(const list&lt; string &gt; &amp;frase):&#160;OP_aux.cc'],['../_o_p__aux_8hh.html#ac9111d87787b58aa6daee2cffb0d03f2',1,'escriure_frase(const list&lt; string &gt; &amp;frase):&#160;OP_aux.cc']]],
  ['escriure_5fsequencia_5ffrases',['escriure_sequencia_frases',['../class_cjt___textos.html#a74f9abb44723c1f4615bd233af083d76',1,'Cjt_Textos']]],
  ['escriure_5ftitol',['escriure_titol',['../_o_p__aux_8cc.html#a390bdbccc899953771fa5865d773fd2c',1,'escriure_titol(const list&lt; string &gt; &amp;titol):&#160;OP_aux.cc'],['../_o_p__aux_8hh.html#a390bdbccc899953771fa5865d773fd2c',1,'escriure_titol(const list&lt; string &gt; &amp;titol):&#160;OP_aux.cc']]]
];
