var searchData=
[
  ['mensaje',['mensaje',['../class_p_r_o2_excepcio.html#aa82c5df8e191f4b6134cd85d270a9e87',1,'PRO2Excepcio']]]
];
