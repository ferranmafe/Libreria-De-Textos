var searchData=
[
  ['main',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['modificar_5fautor',['modificar_autor',['../class_cita.html#a8b057d0c8b6825aabfb5baf22bcff0ea',1,'Cita::modificar_autor()'],['../class_text.html#a7622e7391d7affdf84ccab594bb7f7d8',1,'Text::modificar_autor()']]],
  ['modificar_5fcita',['modificar_cita',['../class_cita.html#a0810a572bc49939318e29a840fb73a41',1,'Cita::modificar_cita()'],['../class_cjt__cites.html#a661c858671a554fe3df0df33c7f7bb2c',1,'Cjt_cites::modificar_cita()']]],
  ['modificar_5ffrase',['modificar_frase',['../class_frase.html#ac88ab94c4fc0bab0776890097af15ef8',1,'Frase::modificar_frase()'],['../class_text.html#a27ce04e7ff0223156493580221bfbdfc',1,'Text::modificar_frase()']]],
  ['modificar_5finici_5ffinal',['modificar_inici_final',['../class_cita.html#aea4ec53ba4e598c5fe9599e195e09900',1,'Cita']]],
  ['modificar_5fn_5fparaules',['modificar_n_paraules',['../class_frase.html#afd605966308dc7dc55b45af01810939e',1,'Frase']]],
  ['modificar_5freferencia',['modificar_referencia',['../class_cita.html#a7caee456196298b7e3e77da860f83d5c',1,'Cita']]],
  ['modificar_5ftaula_5ffrequencies',['modificar_taula_frequencies',['../class_text.html#a75ac9e390d9661c62c38ee37f0f47762',1,'Text']]],
  ['modificar_5ftext',['modificar_text',['../class_cjt___textos.html#ad7482655bb1f878a6324f2d5902fd3ce',1,'Cjt_Textos::modificar_text()'],['../class_text.html#ae01e4bb93495fecf6da658259b10e2fb',1,'Text::modificar_text()']]],
  ['modificar_5ftitol',['modificar_titol',['../class_cita.html#a44c924628e7e6c67d43663fc2ddb115f',1,'Cita::modificar_titol()'],['../class_text.html#a35e2079ce41297d6e6d069f373c65a07',1,'Text::modificar_titol()']]],
  ['mostrar_5fautor',['mostrar_autor',['../class_text.html#a338fe1fe3993abba2f7c43e4bc0f86e8',1,'Text']]],
  ['mostrar_5fcontingut',['mostrar_contingut',['../class_text.html#a203a9a2e6d703390d4eccd50f305f021',1,'Text']]],
  ['mostrar_5ftitol',['mostrar_titol',['../class_text.html#a6ed04dfafee6b0a2b65073d5c6d0cc02',1,'Text']]]
];
