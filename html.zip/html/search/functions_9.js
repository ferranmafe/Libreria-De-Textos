var searchData=
[
  ['operator_3d',['operator=',['../class_arbre.html#a58314b830f6f3ba0e598e352513a87c5',1,'Arbre']]],
  ['ordenar_5fllistes_5fstring',['ordenar_llistes_string',['../_o_p__aux_8cc.html#ac652b496fb290719598d9397c7a916fd',1,'ordenar_llistes_string(const list&lt; string &gt; &amp;a, const list&lt; string &gt; &amp;b):&#160;OP_aux.cc'],['../_o_p__aux_8hh.html#ac652b496fb290719598d9397c7a916fd',1,'ordenar_llistes_string(const list&lt; string &gt; &amp;a, const list&lt; string &gt; &amp;b):&#160;OP_aux.cc']]]
];
