var searchData=
[
  ['nombre_5ffrases',['nombre_frases',['../class_text.html#a5f7b7338cf217a09cf9045ca819e6563',1,'Text']]],
  ['nombre_5fparaules',['nombre_paraules',['../class_text.html#ace001f96970770bf74fec2281d5230b2',1,'Text']]]
];
