var searchData=
[
  ['segd',['segD',['../struct_arbre_1_1node__arbre.html#a9986e206810ba9e519b5b6e590238093',1,'Arbre::node_arbre']]],
  ['sege',['segE',['../struct_arbre_1_1node__arbre.html#add2e7f2ee789db9f38a3bf2d2dd36972',1,'Arbre::node_arbre']]],
  ['seleccionar_5fcomanda_5ffrases',['seleccionar_comanda_frases',['../program_8cc.html#a5f005468907ee60314e34faa550bfbc0',1,'program.cc']]],
  ['string_5fto_5fint',['string_to_int',['../program_8cc.html#a2477fd53342bb311885c0f549879fc91',1,'program.cc']]],
  ['substitueix_5fparaules',['substitueix_paraules',['../class_text.html#ac215dfe9c0bca1ce1e261e7684d18d12',1,'Text']]],
  ['swap',['swap',['../class_arbre.html#a931d1c91e9fd6cbe72703a7ba7d40415',1,'Arbre']]]
];
