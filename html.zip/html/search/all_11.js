var searchData=
[
  ['_7earbre',['~Arbre',['../class_arbre.html#a13cfb8184d9c43d92584d434243c7b3d',1,'Arbre']]],
  ['_7ecita',['~Cita',['../class_cita.html#adfee9096fa1c70127f8bd7523356c85b',1,'Cita']]],
  ['_7ecjt_5fcites',['~Cjt_cites',['../class_cjt__cites.html#a2df89f0c6cccce08f1c7e208d520c146',1,'Cjt_cites']]],
  ['_7ecjt_5ftextos',['~Cjt_Textos',['../class_cjt___textos.html#a8c9f4c38c5f6c7cdfeff8177de95dec1',1,'Cjt_Textos']]],
  ['_7efrase',['~Frase',['../class_frase.html#a1b8938a3bf4bdcde1c1b3b5e09e1de63',1,'Frase']]],
  ['_7etext',['~Text',['../class_text.html#a2d49e5c280e205125b149f7777ae30c7',1,'Text']]]
];
