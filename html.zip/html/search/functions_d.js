var searchData=
[
  ['taula_5ffrequencies',['taula_frequencies',['../class_text.html#a1b074c592cef2ed66b09972dad6d0d4e',1,'Text']]],
  ['text',['Text',['../class_text.html#ab3e26143fccc52699bcc5149cae852bc',1,'Text']]],
  ['text_5ftriat',['text_triat',['../class_cjt___textos.html#a3614f2c2f60b55ecf28eee516ceb6811',1,'Cjt_Textos']]],
  ['textos_5fautor',['textos_autor',['../class_cjt___textos.html#a2fc97e26b63cb253884c5886becadb82',1,'Cjt_Textos']]],
  ['totes_5fcites',['totes_cites',['../class_cjt__cites.html#ab3cf10c876f23dddd104b5a076be6f69',1,'Cjt_cites']]],
  ['tots_5fautors',['tots_autors',['../class_cjt___textos.html#aae43235d551c8b05beacd6b88339f2ea',1,'Cjt_Textos']]],
  ['tots_5ftextos',['tots_textos',['../class_cjt___textos.html#aeb385c50ab07d9f70658ef02698fde77',1,'Cjt_Textos']]],
  ['triar_5ftext',['triar_text',['../class_cjt___textos.html#aa6c2328533e8c8a2f7fc8eab34b6df5f',1,'Cjt_Textos']]]
];
