var searchData=
[
  ['taula_5ffrequencies',['taula_frequencies',['../class_text.html#a1b074c592cef2ed66b09972dad6d0d4e',1,'Text']]],
  ['text',['Text',['../class_text.html',1,'Text'],['../class_text.html#a15cbdc45b63c0314e8fbd1f39ac2c4c1',1,'Text::text()'],['../class_text.html#ab3e26143fccc52699bcc5149cae852bc',1,'Text::Text()']]],
  ['text_2ecc',['Text.cc',['../_text_8cc.html',1,'']]],
  ['text_2ehh',['Text.hh',['../_text_8hh.html',1,'']]],
  ['text_5fmodificat',['text_modificat',['../class_text.html#a2dffce8a1b861805e37492a717a4dc3b',1,'Text']]],
  ['text_5fseleccionat',['text_seleccionat',['../class_cjt___textos.html#ad26e8b990001dc47f643761cd1f78441',1,'Cjt_Textos']]],
  ['text_5ftriat',['text_triat',['../class_cjt___textos.html#a3614f2c2f60b55ecf28eee516ceb6811',1,'Cjt_Textos']]],
  ['textos',['textos',['../class_cjt___textos.html#a388444ce5ae47d22520b07dabdfedb56',1,'Cjt_Textos']]],
  ['textos_5fautor',['textos_autor',['../class_cjt___textos.html#a2fc97e26b63cb253884c5886becadb82',1,'Cjt_Textos']]],
  ['tipus_5fparaules',['tipus_paraules',['../class_text.html#abfbd2a1eb60b44d60d16848fe84d467f',1,'Text']]],
  ['titol',['titol',['../class_cita.html#af68060127129ab645e0134e4ee1e5fbe',1,'Cita::titol()'],['../class_text.html#afb1a3dffe94a4342ea0337f1a40eb5f6',1,'Text::titol()']]],
  ['totes_5fcites',['totes_cites',['../class_cjt__cites.html#ab3cf10c876f23dddd104b5a076be6f69',1,'Cjt_cites']]],
  ['tots_5fautors',['tots_autors',['../class_cjt___textos.html#aae43235d551c8b05beacd6b88339f2ea',1,'Cjt_Textos']]],
  ['tots_5ftextos',['tots_textos',['../class_cjt___textos.html#aeb385c50ab07d9f70658ef02698fde77',1,'Cjt_Textos']]],
  ['triar_5ftext',['triar_text',['../class_cjt___textos.html#aa6c2328533e8c8a2f7fc8eab34b6df5f',1,'Cjt_Textos']]]
];
